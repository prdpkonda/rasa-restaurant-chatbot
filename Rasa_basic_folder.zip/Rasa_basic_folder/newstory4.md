## Generated Story 1566612087842978107
* greet
    - utter_greet
* restaurant_search{"location": "restaurants"}
    - slot{"location": "restaurants"}
    - utter_ask_location
* restaurant_search{"location": "delhi"}
    - slot{"location": "delhi"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_budget
* restaurant_search{"average_cost_for_two": "more than 700"}
    - slot{"average_cost_for_two": "more than 700"}
    - action_restaurant
    - utter_to_email_yes_or_no
* send_email_yes_or_no{"emailyesorno": "yes"}
    - slot{"emailyesorno": "yes"}
    - utter_ask_email
* restaurant_search{"location": "ganesh.doosa@gmail.com"}
    - slot{"location": "ganesh.doosa@gmail.com"}
    - action_send_email_yes_or_no
    - utter_goodbye
    - export

