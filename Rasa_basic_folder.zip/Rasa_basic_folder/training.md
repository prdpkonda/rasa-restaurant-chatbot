## Generated Story 5575656197305734
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "delhi"}
    - slot{"location": "delhi"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
	- utter_ask_budget
* restaurant_search{"average_cost_for_two": "400"}
	- slot{"average_cost_for_two": "400"}
    - action_restaurant
	- utter_to_email_yes_or_no
* send_email_yes_or_no{"emailyesorno":"no"}
	- slot{"emailyesorno":"no"}
	- action_send_email_yes_or_no
    - utter_goodbye
    - export
	
## Generated Story 5575656197305734
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "delhi"}
    - slot{"location": "delhi"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
	- utter_ask_budget
* restaurant_search{"average_cost_for_two": "400"}
	- slot{"average_cost_for_two": "400"}
    - action_restaurant
	- utter_to_email_yes_or_no
* send_email_yes_or_no{"emailyesorno":"yes"}
	- slot{"emailyesorno":"yes"}
	- utter_ask_email
* send_email_yes_or_no{"emailid":"yes"}
	- slot{"emailid":"rasachatbot123@gmail.com"}
	- action_send_email_yes_or_no
    - utter_goodbye
    - export