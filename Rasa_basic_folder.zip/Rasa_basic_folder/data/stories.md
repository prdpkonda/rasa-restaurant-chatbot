## Generated Story -2609945363118667498
* greet
    - utter_ask_howcanhelp
* restaurant_search{"location": "search"}
    - slot{"location": "search"}
    - utter_ask_location
* restaurant_search{"location": "Bangalore"}
    - slot{"location": "Bangalore"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_budget
* restaurant_search{"average_cost_for_two": "more than 700"}
    - slot{"average_cost_for_two": "more than 700"}
    - action_restaurant
    - utter_to_email_yes_or_no
* send_email_yes_or_no{"emailyesorno": "yes", "emailid": "rasachatbot123@gmail.com"}
    - slot{"emailid": "rasachatbot123@gmail.com"}
    - slot{"emailyesorno": "yes"}
    - send_email_yes_or_no
    - utter_goodbye
    - export

## Generated Story -9201959621772740577
* greet
    - utter_ask_howcanhelp
* restaurant_search{"location": "search"}
    - slot{"location": "search"}
    - utter_ask_location
* restaurant_search{"location": "delhi"}
    - slot{"location": "delhi"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_budget
* restaurant_search{"average_cost_for_two": "more than 700"}
    - slot{"average_cost_for_two": "more than 700"}
    - action_restaurant
    - utter_to_email_yes_or_no
* send_email_yes_or_no{"emailyesorno": "no"}
    - slot{"emailyesorno": "no"}
    - send_email_yes_or_no
    - utter_goodbye
    - export
	
## Generated Story 8303928360394751869
* greet
    - utter_ask_howcanhelp
* restaurant_search{"location": "search"}
    - slot{"location": "search"}
    - utter_ask_location
* restaurant_search{"location": "Bangalore"}
    - slot{"location": "Bangalore"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_budget
* restaurant_search{"average_cost_for_two": "more than 700"}
    - slot{"average_cost_for_two": "more than 700"}
    - action_restaurant
    - utter_to_email_yes_or_no
* send_email_with_only_yes{"emailyesorno": "yes"}
    - slot{"emailyesorno": "yes"}
	- utter_ask_email
* get_and_send_email{"emailid": "rasachatbot123@gmail.com"}
    - slot{"emailid": "rasachatbot123@gmail.com"}
    - action_get_and_send_email
    - utter_goodbye
    - export

## Generated Story 2008942075613753615
* greet
    - utter_ask_howcanhelp
* restaurant_search{"location": "search"}
    - slot{"location": "search"}
    - utter_ask_location
* restaurant_search{"location": "Bangalore"}
    - slot{"location": "Bangalore"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_budget
* restaurant_search{"average_cost_for_two": "more than 700"}
    - slot{"average_cost_for_two": "more than 700"}
    - action_restaurant
    - utter_to_email_yes_or_no
* send_email_with_only_no{"emailyesorno": "no"}
    - slot{"emailyesorno": "no"}
    - utter_goodbye
    - export
