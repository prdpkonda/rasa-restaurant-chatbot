from __future__ import absolute_import
from __future__ import division
from __future__ import unicode_literals

import smtplib

from email.message import EmailMessage

from rasa_core.actions.action import Action
from rasa_core.events import SlotSet
import zomatopy
import json
import operator

class ActionSearchRestaurants(Action):
    def name(self):
        return 'action_restaurant'

    def run(self, dispatcher, tracker, domain):
        config = {"user_key": "8a79e1e02b9e0359cc58acfdf7ffb40d"}
        zomato = zomatopy.initialize_app(config)
        
        loc = tracker.get_slot('location') 
                 
        served_locations = ["ahmedabad", "bangalore", "chennai", "delhi", "hyderabad", "kolkata", "mumbai", "pune", "agra", "ajmer", "aligarh", "amravati", "amritsar", "asansol", "aurangabad", "bareilly", "belgaum", "bhavnagar", "bhiwandi", "bhopal", "bhubaneswar", "bikaner", "bokaro steel city", "chandigarh", "coimbatore", "cuttack", "dehradun", "dhanbad", "durg-bhilai nagar", "durgapur", "erode", "faridabad", "firozabad", "ghaziabad", "gorakhpur", "gulbarga", "guntur", "gurgaon", "guwahati‚ gwalior", "hubli-dharwad", "indore", "jabalpur", "jaipur", "jalandhar", "jammu", "jamnagar", "jamshedpur", "jhansi", "jodhpur", "kannur", "kanpur", "kakinada", "kochi", "kottayam", "kolhapur", "kollam", "kota", "kozhikode", "kurnool", "lucknow", "ludhiana", "madurai", "malappuram", "mathura", "goa", "mangalore", "meerut", "moradabad", "mysore", "nagpur", "nanded", "nashik", "nellore", "noida", "palakkad", "patna", "pondicherry", "prayagraj", "raipur", "rajkot", "rajahmundry", "ranchi", "rourkela", "salem", "sangli", "siliguri", "solapur", "srinagar", "sultanpur", "surat", "thiruvananthapuram", "thrissur", "tiruchirappalli", "tirunelveli", "tiruppur", "ujjain", "bijapur", "vadodara", "varanasi", "vasai-virar city", "vijayawada", "visakhapatnam", "warangal"]
        if loc.lower() not in served_locations:
            dispatcher.utter_message("We do not operate in that area yet.")
            return
        
        average_cost_for_two = tracker.get_slot('average_cost_for_two')
        print("log => average_cost_for_two =",average_cost_for_two)
        # Extract integers from this
        extracted = [int(s) for s in average_cost_for_two.split() if s.isdigit()]
        print("log => extracted budget range = ",extracted)
        if len(extracted)==1:
            average_cost_for_two = extracted[0]
        elif len(extracted)==2:
            start_range = min(extracted)
            end_range = max(extracted)
            average_cost_for_two = (start_range + end_range) / 2

        average_cost_for_two = str(average_cost_for_two)
        
        if not average_cost_for_two:           
            average_cost_for_two = '0'
            print("Not able to pick average budget whcih is none")

        cuisine = tracker.get_slot('cuisine')
        location_detail = zomato.get_location(loc, 1)
        d1 = json.loads(location_detail)
        lat = d1["location_suggestions"][0]["latitude"]
        lon = d1["location_suggestions"][0]["longitude"]
        cuisines_dict = {'bakery': 5, 'chinese': 25, 'cafe': 30, 'italian': 55, 'biryani': 7, 'north indian': 50,
                         'south indian': 85, 'american' : 1,'mexican' : 73}
        results = zomato.restaurant_search("", lat, lon, str(cuisines_dict.get(cuisine)), average_cost_for_two, 10)
        d = json.loads(results)
        sorted_list =  sorted(d['restaurants'], key = lambda i: float(str(i['restaurant']['user_rating']['aggregate_rating'])), reverse=True)
        global response
        response = ''
        response_5 = ''
        if d['results_found'] == 0:
            response = "no results"
        else:
            for index, restaurant in enumerate(sorted_list):
                if index < 5:
                    response_5 = response_5 + " " + restaurant['restaurant']['name'] + " in " + \
                           restaurant['restaurant']['location']['address'] + ". Rating:" + str(
                    restaurant['restaurant']['user_rating'][
                        'aggregate_rating']) + "  And the average price for two people here is: " + str(
                    restaurant['restaurant']['average_cost_for_two']) + "\n"
                response = response + " " + restaurant['restaurant']['name'] + " in " + \
                           restaurant['restaurant']['location']['address'] + ". Rating:" + str(
                    restaurant['restaurant']['user_rating'][
                        'aggregate_rating']) + "  And the average price for two people here is: " + str(
                    restaurant['restaurant']['average_cost_for_two']) + "\n"

        dispatcher.utter_message("----- Showing you top rated restaurants -----\n" + response_5 + "----- End -----\n")


class SendEmailYesOrNo(Action):
    def name(self):
        return 'send_email_yes_or_no'

    def run(self, dispatcher, tracker, domain):

        emailyesorno = tracker.get_slot('emailyesorno')
        emailid = tracker.get_slot('emailid')
        if not emailyesorno:
            emailyesorno = 'no'
        if emailyesorno == 'yes':
            self.send_email(emailid)
        else:
            dispatcher.utter_message("goodbye")
			
    def send_email(self,emailid):
        global response
        gmail_user = 'rasachatbot123@gmail.com'
        gmail_password = 'strongPassword123:'

        # Connect to server
        try:
            server = smtplib.SMTP_SSL('smtp.gmail.com', 465)
            server.ehlo()
            server.login(gmail_user, gmail_password)
        except Exception as e:
            print('Could not connect...', e)
            return

        sent_from = gmail_user
        to = emailid
        body = response

        msg = EmailMessage()
        msg.set_content(response)
        msg['Subject'] = 'Your restaurant search results'
        msg['From'] = gmail_user
        msg['To'] = emailid
        print('log -> sending mail to emailid ',emailid)
        try:
            server = smtplib.SMTP_SSL('smtp.gmail.com', 465)
            server.ehlo()
            server.login(gmail_user, gmail_password)
            server.sendmail(sent_from, to, msg.as_bytes())
            server.close()

            print('Email sent!')
        except Exception  as e:
            print('Could not send email...', e)
    

class SendEmailWithOnlyYes(Action):
    def name(self):
        return 'send_email_with_only_yes'

    def run(self, dispatcher, tracker, domain):

        dispatcher.utter_message("Please provide email address")
        


class SendEmailWithOnlyNo(Action):
    def name(self):
        return 'send_email_with_only_no'

    def run(self, dispatcher, tracker, domain):

        dispatcher.utter_message("goodbye")
		
class GetAndSendEmail(Action):
    def name(self):
        return 'action_get_and_send_email'

    def run(self, dispatcher, tracker, domain):

        emailid = tracker.get_slot('emailid')
        if not emailid:
            dispatcher.utter_message("Invalid Email Address.")
        else:
            self.send_email(emailid)
            dispatcher.utter_message("Thanks!!")

    def send_email(self,emailid):
        global response
        gmail_user = 'rasachatbot123@gmail.com'
        gmail_password = 'strongPassword123:'

        # Connect to server
        try:
            server = smtplib.SMTP_SSL('smtp.gmail.com', 465)
            server.ehlo()
            server.login(gmail_user, gmail_password)
        except Exception as e:
            print('Could not connect...', e)
            return

        sent_from = gmail_user
        to = emailid
        body = response

        msg = EmailMessage()
        msg.set_content(response)
        msg['Subject'] = 'Your restaurant search results'
        msg['From'] = gmail_user
        msg['To'] = emailid
        print('log -> sending mail to emailid ',emailid)
        try:
            server = smtplib.SMTP_SSL('smtp.gmail.com', 465)
            server.ehlo()
            server.login(gmail_user, gmail_password)
            server.sendmail(sent_from, to, msg.as_bytes())
            server.close()

            print('Email sent!')
        except Exception  as e:
            print('Could not send email...', e)

class ActionValidateLocation(Action):
    def name(self):
        return 'validate_location'

    def run(self, dispatcher, tracker, domain):      
        loc = tracker.get_slot('location')
        served_locations = ["ahmedabad", "bangalore", "chennai", "delhi", "hyderabad", "kolkata", "mumbai", "pune", "agra", "ajmer", "aligarh", "amravati", "amritsar", "asansol", "aurangabad", "bareilly", "belgaum", "bhavnagar", "bhiwandi", "bhopal", "bhubaneswar", "bikaner", "bokaro steel city", "chandigarh", "coimbatore", "cuttack", "dehradun", "dhanbad", "durg-bhilai nagar", "durgapur", "erode", "faridabad", "firozabad", "ghaziabad", "gorakhpur", "gulbarga", "guntur", "gurgaon", "guwahati‚ gwalior", "hubli-dharwad", "indore", "jabalpur", "jaipur", "jalandhar", "jammu", "jamnagar", "jamshedpur", "jhansi", "jodhpur", "kannur", "kanpur", "kakinada", "kochi", "kottayam", "kolhapur", "kollam", "kota", "kozhikode", "kurnool", "lucknow", "ludhiana", "madurai", "malappuram", "mathura", "goa", "mangalore", "meerut", "moradabad", "mysore", "nagpur", "nanded", "nashik", "nellore", "noida", "palakkad", "patna", "pondicherry", "prayagraj", "raipur", "rajkot", "rajahmundry", "ranchi", "rourkela", "salem", "sangli", "siliguri", "solapur", "srinagar", "sultanpur", "surat", "thiruvananthapuram", "thrissur", "tiruchirappalli", "tirunelveli", "tiruppur", "ujjain", "bijapur", "vadodara", "varanasi", "vasai-virar city", "vijayawada", "visakhapatnam", "warangal"]
        if loc.lower() not in served_locations:
            dispatcher.utter_message("We do not operate in that area yet.")
            return
        else:
            dispatcher.utter_message("You chose " + loc)