## Generated Story -2306006557337446235
* greet
    - utter_greet
* restaurant_search{"location": "restaurants"}
    - slot{"location": "restaurants"}
    - utter_ask_location
* restaurant_search{"location": "karimnagar"}
    - slot{"location": "karimnagar"}
    - validate_location
* restaurant_search{"location": "delhi"}
    - slot{"location": "delhi"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_budget
* restaurant_search{"average_cost_for_two": "more than 700"}
    - slot{"average_cost_for_two": "more than 700"}
    - action_restaurant
    - utter_to_email_yes_or_no
* send_email
    - action_send_email_yes_or_no
    - utter_goodbye
    - export

